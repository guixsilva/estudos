﻿
public interface ICriterioDeSeparacao<Dado>
{
  bool DeveSeparar();
}

