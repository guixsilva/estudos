﻿
public interface IRegistro
{
  string FormatoDeArquivo();
}

